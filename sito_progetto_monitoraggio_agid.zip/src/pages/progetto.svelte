<script>
  import ProgettoMain from "../lib/components/ProgettoMain.svelte";
</script>

<svelte:head>
  <title>Il Progetto - Monitoraggio Accessibilità</title>
</svelte:head>

<section aria-label="Sezione progetto">
  <ProgettoMain />
</section>

<script>
  import ContattiMain from "../lib/components/ContattiMain.svelte";
</script>

<svelte:head>
  <title>Contatti - Monitoraggio Accessibilità</title>
</svelte:head>

<section aria-label="Sezione contatti">
  <ContattiMain />
</section>

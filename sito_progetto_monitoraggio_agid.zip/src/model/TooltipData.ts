export type TooltipData = {
    id: string,
    content: {
        header: string,
        body: string
    }
}
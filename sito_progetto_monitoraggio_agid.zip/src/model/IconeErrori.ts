export type IconaErrori = {
    id: string;
    icon: string;
    href_eng: string;
    href_ita: string;
}


